package com.servlet;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.data.Student;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;

/**
 * Servlet implementation class CheckCodeServlet
 */
@WebServlet("/CheckCodeServlet")
public class CheckCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Data data;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckCodeServlet() {
		super();
		data = new Data();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("port.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

//	request.setAttribute("error",errorMsg);
//
//	doGet(request, response);
//
//        response.setContentType("text/html;charset=utf-8");
//        PrintWriter pw = response.getWriter();
//        // pw.write(resultTip);
//        pw.flush();
//        pw.close();
//
//    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String studentNumber = request.getParameter("studentNumber");
		int portNumber1 = Integer.parseInt(request.getParameter("portNumber1"));
		int portNumber2 = Integer.parseInt(request.getParameter("portNumber2"));

		Student student = new Student(studentNumber, portNumber1, portNumber2);
		int valid = data.tryAddStudent(student);

		String errorMsg = "success";
		switch (valid) {
		case 0:
			errorMsg = "success";
			Mailer mailer = new Mailer("smtp.163.com", "13932401123@163.com", "Zyfshr19940227", "13932401123@163.com",
					student.toString());
			try {
				mailer.send();
			} catch (Exception e) {
				e.printStackTrace();
				errorMsg = "mail send error";
			}
			break;
		case 1:
			errorMsg = "port 1 in use";
			break;
		case 2:
			errorMsg = "port 2 in use";
			break;
		default:
			errorMsg = "error encountered";
			break;
		}
		request.setAttribute("error", errorMsg);
		request.getRequestDispatcher("port.jsp").forward(request,response);
	}

}
