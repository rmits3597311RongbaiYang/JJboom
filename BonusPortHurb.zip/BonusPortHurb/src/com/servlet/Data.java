package com.servlet;

import java.util.ArrayList;
import java.util.List;

import com.data.Student;


public class Data {
    private static List<Student> studentList;
    public Data() {
        studentList = new ArrayList<>();
    }

    public int tryAddStudent(Student target) {
        for (Student student : studentList) {
            if (target.getStudentNumber().equals(student.getStudentNumber())) return -1;
            if (target.getPortNumber1() == student.getPortNumber1()) return 1;
            if (target.getPortNumber2() == student.getPortNumber2()) return 2;
        }
        studentList.add(target);
        return 0;
    }

}
