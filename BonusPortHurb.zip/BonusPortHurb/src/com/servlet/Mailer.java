package com.servlet;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class Mailer {
    private String host;
    private String from;
    private String password;
    private String toEmailAddress;
    private String body;

    public Mailer(String host, String from, String password, String toEmailAddress, String body) {
        this.host = host;
        this.from = from;
        this.password = password;
        this.toEmailAddress = toEmailAddress;
        this.body = body;
    }

    public void send() throws Exception {
        Properties properties = System.getProperties();
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.user", from);
        properties.put("mail.smtp.password", password);
        properties.put("mail.smtp.port", "25");
        properties.put("mail.smtp.auth", "true");

        Session mailSession = Session.getDefaultInstance(properties, null);
        Message message = new MimeMessage(mailSession);
        message.setFrom(new InternetAddress(from));
        message.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmailAddress));
        message.setSubject("Student Port Number from");
        message.setContent(body,"text/html");

        Transport transport = mailSession.getTransport("smtp");
        transport.connect(host, from, password);
        transport.sendMessage(message, message.getAllRecipients());
        transport.close();
    }
}
